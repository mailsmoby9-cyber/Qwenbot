# Разработка и сборка на Android (ARM64)

Этот проект не требует ПК: редактировать код и получать готовый JAR можно прямо
с телефона. Ниже — два рабочих варианта.

---

## Вариант 1. GitHub в браузере (самый простой)

**Что понадобится:** аккаунт GitHub, браузер или GitHub App, файловый менеджер.

1. Создайте репозиторий на GitHub (например, `ultra-triggerbot`) и залейте сюда
   содержимое этой папки (можно архивом через веб-интерфейс).
2. Для правки файлов открывайте нужный файл → значок карандаша → измените →
   `Commit changes`.
3. После каждого коммита автоматически запускается
   `.github/workflows/build.yml` (вкладка **Actions**).
4. Когда статус станет зелёным, откройте запуск → блок **Artifacts** →
   `ultra-triggerbot` → скачайте ZIP.
5. Распакуйте ZIP в файловом менеджере и извлеките
   `ultra-triggerbot-1.0.0.jar`.
6. Поместите JAR в папку `mods` вашего Minecraft Java (например, в PojavLauncher:
   `Documents/pojav/mods` или туда, куда указывает профиль).
7. Запустите Minecraft с Fabric Loader 0.20.1+ и Fabric API 0.141.6+1.21.11.

**Совет:** чтобы не ловить ошибки, перед коммитом можно быстро проверить
синтаксис прямо в веб-редакторе — он подсвечивает Java-ошибки.

---

## Вариант 2. Termux + Acode (полная локальная сборка)

### 1. Установка окружения

```bash
pkg update -y
pkg install -y openjdk-21 git unzip curl
termux-setup-storage
```

> Если `openjdk-21` недоступен в вашем репозитории, поставьте
> `openjdk-17` и временно замените `JavaLanguageVersion` на 17 в `build.gradle`
> (.compose для 1.21.11 всё равно рекомендуется Java 21).

### 2. Редактор

Установите **Acode** (F-Droid / Play Market) и откройте папку проекта —
подсветка Java и Gradle есть из коробки. Альтернатива — **CodeEditor**.

### 3. Клонирование и сборка

```bash
cd /sdcard
git clone <URL_ВАШЕГО_РЕПОЗИТОРИЯ> ultra-triggerbot
cd ultra-triggerbot
chmod +x gradlew
./gradlew build --no-daemon
```

Первый запуск скачивает Gradle 9.8.2 (~130 МБ), Minecraft и зависимости.
На ARM64 всё работает нативно (без эмуляции x86).

### 4. Если память ограничена

В `gradle.properties` уже выставлено:

```properties
org.gradle.jvmargs=-Xmx1G -XX:MaxMetaspaceSize=512m
```

При нехватке памяти уменьшите до `-Xmx768m`, но сборка может замедлиться.

### 5. Доставка JAR в игру

```bash
cp build/libs/ultra-triggerbot-1.0.0.jar /sdcard/Download/
```

Дальше — через файловый менеджер положите файл в папку `mods` профиля
PojavLauncher или другого Java-запускателя.

---

## Типичные проблемы на Android

| Проблема | Решение |
|---|---|
| `./gradlew: Permission denied` | `chmod +x gradlew` |
| `Could not determine java version` | Установите JDK 21: `pkg install openjdk-21` |
| `OutOfMemoryError` | Уменьшите `-Xmx` в `gradle.properties` |
| Медленная загрузка зависимостей | Дождитесь первой сборки; дальше Gradle кеширует их |
| Мод не видно в игре | Проверьте версии: Minecraft 1.21.11, Fabric Loader 0.20.1+, Fabric API 0.141.6+1.21.11 |
| Клавиша R не реагирует | Откройте `Options → Controls → Ultra Triggerbot` и назначьте клавишу заново |

---

## Обновление мода

1. Измените `mod_version` в `gradle.properties`.
2. Сделайте коммит — CI соберёт новый артефакт.
3. Скачайте новый JAR и замените старый в папке `mods`.
