# Ultra Triggerbot — Fabric 1.21.11

Клиентский PvP-триггербот для Minecraft Java 1.21.11 (Fabric) с мгновенной реакцией,
умным sprint reset и индикатором состояния. Проект собирается в GitHub Actions —
разрабатывать можно прямо с телефона, без локального ПК.

> Мод работает **только на клиенте**, не добавляет серверных функций и не отправляет
> собственных сетевых пакетов. Использование таких модов на серверах может нарушать
> их правила — включайте на свой страх и риск.

---

## Возможности

- **Мгновенный отклик:** цель определяется в `START_CLIENT_TICK`, атака — в конце тика
  клиентского игрока. Никаких таймеров, очередей с задержкой и искусственных пауз.
- **Точный выбор цели:** ванильный raycast через `getCrosshairTarget()` учитывает блоки,
  хитбоксы и интерполяцию, поэтому движущиеся цели отслеживаются стабильно.
- **Защита от ложных срабатываний:** проверка дистанции (3.05), живости, атакуемости,
  spectator-режима, удаления сущности, cooldown'а и открытого GUI.
- **Ultra-legit sprint reset:** сброс спринта только тогда, когда реально возможен крит
  (прыжок/падение), применяется **до** отправки movement-пакетов и автоматически
  восстанавливается, если игрок всё ещё удерживает бег.
- **Криты по игровым условиям:** без «магических»knockback-пакетов и подмены velocity.
- **Индикатор ON/OFF** прямо в игровом HUD + всплывающее сообщение при переключении.
- **Низкие накладные расходы:** в «горячем пути» нет аллокаций и рефлексии; код
  совместим с Sodium (не задевает рендер и сетевой стек).

---

## Требования

| Компонент | Версия |
|---|---|
| Minecraft | 1.21.11 |
| Fabric Loader | 0.20.1+ |
| Fabric API | 0.141.6+1.21.11 |
| Java (сборка) | 21 (Temurin) |
| Gradle Wrapper | 9.8.2 |
| Loom | 1.17.21 (`net.fabricmc.fabric-loom-remap`, совместим с Java 21) |
| Mappings | Yarn 1.21.11+build.6 (v2) |

Для запуска на Android ARM64 достаточно обычного Java 21 runtime (например,
PojavLauncher), сам JAR платформо-независим.

---

## Быстрый старт с телефона (рекомендуется)

1. Откройте репозиторий в GitHub App / браузере.
2. Внесите изменения через веб-редактор (`Editing files` → карандаш).
3. Сделайте `Commit changes`. Это автоматически запустит `.github/workflows/build.yml`.
4. Откройте вкладку **Actions** → последний запуск → артефакт `ultra-triggerbot`.
5. Скачайте ZIP, распакуйте и достаньте `ultra-triggerbot-1.0.0.jar`.
6. Положите JAR в `mods` вашего запускателя Minecraft Java (PojavLauncher и т.п.).

Подробности — в [ANDROID.md](ANDROID.md).

### Вариант Termux (сборка прямо на устройстве)

```bash
pkg update -y && pkg install -y openjdk-21 git unzip curl
git clone <URL_РЕПОЗИТОРИЯ>
cd ultra-triggerbot
./gradlew build --no-daemon
cp build/libs/ultra-triggerbot-1.0.0.jar /sdcard/Download/
```

> На слабых устройствах добавьте `-Xmx1G` в `gradle.properties` (уже выставлено).
> Первая сборка скачивает Minecraft и зависимости — это может занять несколько минут.

---

## Сборка на ПК / CI

```bash
./gradlew build --no-daemon
```

Готовый файл: `build/libs/ultra-triggerbot-1.0.0.jar`.

Проверка без запуска игрового клиента:

```bash
./gradlew check --no-daemon
```

GitHub Actions выполняет ту же команду и загружает результат как артефакт.

---

## Управление

| Клавиша | Действие |
|---|---|
| **R** | Включить / выключить триггербот (мгновенно, без конфликтов) |

Клавишу можно переназначить в `Options → Controls → Ultra Triggerbot`.
Индикатор в правом верхнем углу экрана показывает `IN` (зелёный) или `OFF` (красный).

---

## Структура проекта

```
.
├── .github/workflows/build.yml        # CI: сборка и загрузка артефакта
├── gradle/wrapper/                    # Gradle Wrapper 9.8.2
├── src/main/java/com/ultratriggerbot/
│   ├── UltraTriggerbotMod.java        # Точка входа, keybind, события Fabric
│   ├── TriggerBot.java                # Машина состояний, цель, sprint reset
│   └── mixin/
│       ├── MinecraftClientAccessor.java  # Доступ к attackCooldown
│       ├── ClientPlayerEntityAccessor.java  # Доступ к счётчику double-tap спринта
│       ├── ClientPlayerEntityMixin.java  # Точки внедрения в тик игрока
│       └── InGameHudMixin.java           # Индикатор ON/OFF
├── src/main/resources/
│   ├── fabric.mod.json
│   ├── ultra-triggerbot.mixins.json
│   └── assets/ultra-triggerbot/
│       ├── icon.png
│       └── lang/{en_us,ru_ru}.json
├── build.gradle
├── gradle.properties
├── settings.gradle
└── README.md / ANDROID.md / LICENSE / .gitignore
```

---

## Технические подробности

- **Cooldown:** после успешной атаки поле `MinecraftClient.attackCooldown` выставляется
  в 6 тиков вручную (эквивалент ванильного меча), что исключает двойные атаки.
- **Порядок тика:**
  1. `START_CLIENT_TICK` — проверка ввода, поиск цели, планирование сброса спринта.
  2. `ClientPlayerEntity.tick()` перед `sendMovementPackets()` — `setSprinting(false)`.
  3. Конец `ClientPlayerEntity.tick()` — `attackEntity()` + восстановление спринта.
- **Безопасное отключение:** при выключении, выходе из мира, смерти, открытии GUI или
  ошибке все отложенные действия очищаются, а спринт возвращается в исходное состояние.
- **Нет packet hooks и reflection** — только публичные API Fabric/Yarn и миксины.

---

## Известные ограничения

- Работает только в одиночном/сетевом clientside-контексте; сервер всё равно
  авторитетно проверяет дистанцию и cooldown (как в ванильном PvP).
- Точность crits зависит от реального состояния игрока (прыжок/падение) — мод не
  создаёт искусственные криты.
- При очень низком FPS (<10) устаревшие отложенные атаки отбрасываются.
- На серверах с строгими правилами использование может привести к бану.

---

## Лицензия

MIT — см. [LICENSE](LICENSE).
