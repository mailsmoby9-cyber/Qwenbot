package com.ultratriggerbot.mixin;

import com.ultratriggerbot.TriggerBot;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Small, cheap always-visible ON/OFF indicator. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
	@Inject(method = "render", at = @At("TAIL"))
	private void ultraTriggerbot$renderIndicator(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		boolean enabled = TriggerBot.get().isEnabled();
		context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer,
				Text.literal(enabled ? "§a§lIN" : "§c§lOFF"), 4, 4, 0xFFFFFF);
	}
}
