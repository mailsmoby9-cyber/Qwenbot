package com.ultratriggerbot.mixin;

import com.ultratriggerbot.TriggerBot;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Two injection points inside the single player tick:
 *  - right before the movement packet is built (sprint reset becomes visible
 *    to the server BEFORE the attack packet);
 *  - at the very end of the tick (one queued attack, never a backlog).
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
	@Inject(
			method = "tick",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/network/ClientPlayerEntity;sendMovementPackets()V",
					shift = At.Shift.BEFORE
			)
	)
	private void ultraTriggerbot$beforeMovement(CallbackInfo ci) {
		TriggerBot.get().applyPreMovement((ClientPlayerEntity) (Object) this);
	}

	@Inject(method = "tick", at = @At("TAIL"))
	private void ultraTriggerbot$afterTick(CallbackInfo ci) {
		TriggerBot.get().performQueuedAttack((ClientPlayerEntity) (Object) this);
	}
}
