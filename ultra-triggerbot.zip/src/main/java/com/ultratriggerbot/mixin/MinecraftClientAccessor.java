package com.ultratriggerbot.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Direct access to the vanilla melee cooldown (no reflection, no per-tick lookups). */
@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
	@Accessor("attackCooldown")
	int getAttackCooldown();

	@Accessor("attackCooldown")
	void setAttackCooldown(int cooldown);
}
