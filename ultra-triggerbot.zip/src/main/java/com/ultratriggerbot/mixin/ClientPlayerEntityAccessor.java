package com.ultratriggerbot.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Access to the vanilla double-tap sprint counter, so we can restore exactly the original sprint state. */
@Mixin(ClientPlayerEntity.class)
public interface ClientPlayerEntityAccessor {
	@Accessor("ticksLeftToDoubleTapSprint")
	int getTicksLeftToDoubleTapSprint();
}
