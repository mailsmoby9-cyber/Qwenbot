package com.ultratriggerbot;

import com.ultratriggerbot.mixin.ClientPlayerEntityAccessor;
import com.ultratriggerbot.mixin.MinecraftClientAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * Core state machine. Runs on the client render thread only, allocates nothing
 * in the hot path and queues at most ONE attack per game tick.
 */
public final class TriggerBot {
	private static final TriggerBot INSTANCE = new TriggerBot();

	/** Vanilla attack cooldown. We set it ourselves because we bypass doAttack(). */
	private static final int ATTACK_COOLDOWN_TICKS = 6;
	/** Vanilla melee reach (survival). */
	private static final double MAX_REACH = 3.05;
	/** Below this downward velocity a critical hit is not possible. */
	private static final double CRIT_FALL_SPEED = -0.05;

	private boolean enabled;
	private boolean attackQueued;
	private boolean sprintSuppressionPlanned;
	private boolean sprintSuppressionApplied;
	private Entity queuedTarget;
	private long queuedAtTick;

	private TriggerBot() {
	}

	public static TriggerBot get() {
		return INSTANCE;
	}

	public boolean isEnabled() {
		return enabled;
	}

	/** R key: instant toggle, with immediate safe cleanup when disabling. */
	public void onToggle(MinecraftClient client) {
		enabled = !enabled;
		if (!enabled) {
			reset(client);
		}
		if (client.player != null) {
			client.player.sendMessage(Text.literal(enabled ? "§a[ULTRA TRIGGERBOT] ON"
					: "§c[ULTRA TRIGGERBOT] OFF"), true);
		}
	}

	/** Called on world join/disconnect and on disable. Never leaves sprint stuck. */
	public void reset(MinecraftClient client) {
		clear(client.player, true);
		enabled = false;
	}

	/**
	 * START_CLIENT_TICK: target detection + scheduling.
	 * The real attack is executed from the client tick mixin AFTER movement
	 * packets have been sent, so a sprint reset is visible to the server first.
	 */
	public void onStartTick(MinecraftClient client) {
		if (UltraTriggerbotMod.toggleKey() != null && UltraTriggerbotMod.toggleKey().wasPressed()) {
			onToggle(client);
		}

		ClientPlayerEntity player = client.player;
		if (!enabled || player == null || client.world == null) {
			return;
		}

		long now = client.world.getTime();
		if (attackQueued && now - queuedAtTick > 1L) {
			// Stale action from a lag spike / low FPS: never execute delayed attacks.
			clear(player, true);
		}
		if (client.currentScreen != null || !player.isAlive() || player.isSpectator()) {
			clear(player, true);
			return;
		}
		if (((MinecraftClientAccessor) client).getAttackCooldown() > 0) {
			clear(player, true);
			return;
		}

		Entity target = resolveTarget(client);
		if (target == null) {
			clear(player, true);
			return;
		}

		queuedTarget = target;
		attackQueued = true;
		queuedAtTick = now;

		// Ultra-legit reset: only when a crit is actually possible and only
		// while sprinting. No periodic on/off toggling, no movement edits.
		sprintSuppressionPlanned = player.isSprinting() && canCrit(player);
	}

	/**
	 * Called from ClientPlayerEntity.tick() immediately BEFORE sendMovementPackets().
	 * Guarantees the sprint=false state is included in the very next movement packet.
	 */
	public void applyPreMovement(ClientPlayerEntity player) {
		if (attackQueued && sprintSuppressionPlanned && player.isSprinting()) {
			player.setSprinting(false);
			sprintSuppressionApplied = true;
		}
	}

	/** Called at the very end of ClientPlayerEntity.tick(). */
	public void performQueuedAttack(ClientPlayerEntity player) {
		if (!attackQueued || queuedTarget == null) {
			return;
		}
		if (!enabled || !player.isAlive() || player.isSpectator()) {
			clear(player, true);
			return;
		}

		MinecraftClient client = MinecraftClient.getInstance();
		Entity target = queuedTarget;
		boolean stillValid = target.isAlive()
				&& target.isAttackable()
				&& !target.isRemoved()
				&& target.getEntityWorld() == client.world
				&& player.distanceTo(target) <= MAX_REACH
				&& ((MinecraftClientAccessor) client).getAttackCooldown() <= 0;

		attackQueued = false;
		queuedTarget = null;
		sprintSuppressionPlanned = false;

		if (!stillValid) {
			restoreSprint(player);
			return;
		}

		client.interactionManager.attackEntity(player, target);
		((MinecraftClientAccessor) client).setAttackCooldown(ATTACK_COOLDOWN_TICKS);
		restoreSprint(player);
	}

	private void restoreSprint(ClientPlayerEntity player) {
		if (!sprintSuppressionApplied) {
			return;
		}
		sprintSuppressionApplied = false;
		// Restore only if the player still wants to run: sprint key held OR
		// vanilla's double-tap sprint window is still active.
		boolean sprintKey = player.input != null && player.input.playerInput != null
				&& player.input.playerInput.sprint();
		boolean doubleTap = ((ClientPlayerEntityAccessor) player).getTicksLeftToDoubleTapSprint() > 0;
		if (sprintKey || doubleTap) {
			player.setSprinting(true);
		}
	}

	private void clear(ClientPlayerEntity player, boolean restoreSprint) {
		if (restoreSprint && player != null) {
			restoreSprint(player);
		}
		attackQueued = false;
		sprintSuppressionPlanned = false;
		queuedTarget = null;
	}

	private static boolean canCrit(ClientPlayerEntity player) {
		return !player.isOnGround()
				&& player.getVelocity().y < CRIT_FALL_SPEED
				&& !player.isTouchingWater()
				&& !player.isInLava()
				&& !player.isGliding()
				&& !player.hasStatusEffect(StatusEffects.BLINDNESS)
				&& player.getVehicle() == null;
	}

	private static Entity resolveTarget(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.getCameraEntity() == null) {
			return null;
		}

		// Vanilla raycast: accounts for blocks, hitboxes and tick interpolation,
		// so a moving target is tracked without extra prediction or delays.
		HitResult hit = player.getCrosshairTarget(
				client.getRenderTickCounter().getTickProgress(false), client.getCameraEntity());
		if (hit == null || hit.getType() != HitResult.Type.ENTITY) {
			return null;
		}

		Entity target = ((EntityHitResult) hit).getEntity();
		if (target == player || target == player.getVehicle()) {
			return null;
		}
		if (!target.isAlive() || !target.isAttackable() || target.isSpectator() || target.isRemoved()) {
			return null;
		}
		if (player.distanceTo(target) > MAX_REACH) {
			return null;
		}
		return target;
	}
}
