package com.ultratriggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import org.lwjgl.glfw.GLFW;

/**
 * Client entry point. No server-side code, no packet hooks, no reflection.
 */
public final class UltraTriggerbotMod implements ClientModInitializer {
	public static final String MOD_ID = "ultra-triggerbot";

	private static KeyBinding toggleKey;

	@Override
	public void onInitializeClient() {
		// 3-arg constructor = translation key, GLFW key code, category.
		// No manual key polling: Fabric handles conflicts and key-binding menus.
		toggleKey = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.ultra-triggerbot.toggle", GLFW.GLFW_KEY_R, KeyBinding.Category.MISC));

		ClientTickEvents.START_CLIENT_TICK.register(UltraTriggerbotMod::onStartTick);
		ClientPlayConnectionEvents.JOIN.register(UltraTriggerbotMod::onJoin);
		ClientPlayConnectionEvents.DISCONNECT.register(UltraTriggerbotMod::onDisconnect);
	}

	static KeyBinding toggleKey() {
		return toggleKey;
	}

	private static void onStartTick(MinecraftClient client) {
		TriggerBot.get().onStartTick(client);
	}

	private static void onJoin(ClientPlayNetworkHandler handler, PacketSender sender, MinecraftClient client) {
		TriggerBot.get().reset(client);
	}

	private static void onDisconnect(ClientPlayNetworkHandler handler, MinecraftClient client) {
		TriggerBot.get().reset(client);
	}
}
