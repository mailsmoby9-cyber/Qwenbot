package dev.wrench.trigger;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class TriggerMod implements ClientModInitializer {
    public static final String ID = "funtrigger";
    private static final Logger LOG = LoggerFactory.getLogger(ID);

    @Override
    public void onInitializeClient() {
        TriggerConfig cfg = TriggerConfig.loadOrCreate(
                FabricLoader.getInstance().getConfigDir().resolve(ID + ".properties"), LOG);
        TriggerEngine engine = new TriggerEngine(cfg);
        ClientTickEvents.START_CLIENT_TICK.register(engine::onStartTick);
        ClientTickEvents.END_CLIENT_TICK.register(engine::onEndTick);
        LOG.info("Trigger loaded (toggle key code {}).", cfg.toggleKey);
    }
}
