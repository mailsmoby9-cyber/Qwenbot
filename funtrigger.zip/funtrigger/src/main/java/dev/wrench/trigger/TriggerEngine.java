package dev.wrench.trigger;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

/**
 * START tick: hotkey, sprint restore, target tracking. END tick (after the player ticked and its movement
 * packets went out): the whole decision and the vanilla attack path, so a hit goes out in the first tick
 * the conditions hold. For crits the sprint is dropped one tick ahead (at the top of the jump) by releasing
 * the forward key like a manual W-tap, so the first falling tick can already hit.
 */
public final class TriggerEngine {
    private final TriggerConfig cfg;
    private final Hotkey hotkey = new Hotkey();
    private final SprintReset sprint = new SprintReset();

    private final Map<Integer, Vec3d> lastPos = new HashMap<>();
    private final Map<Integer, Vec3d> velocity = new HashMap<>();

    private boolean enabled;
    private double lead;
    private int targetId = Integer.MIN_VALUE;
    private int reactionLeft = -1;
    private int risingWaited;
    private boolean preArmed;

    public TriggerEngine(TriggerConfig cfg) {
        this.cfg = cfg;
    }

    public void onStartTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            enabled = false;
            cycleReset(mc);
            return;
        }

        boolean focused = Hotkey.windowFocused();
        boolean edge = hotkey.pollEdge(cfg.toggleKey);
        if (edge && focused && mc.currentScreen == null) {
            enabled = !enabled;
            if (cfg.showToggleMessage) {
                p.sendMessage(Text.literal("Trigger: " + (enabled ? "ON" : "OFF")), true);
            }
        }

        sprint.onStartTick(mc, p);

        if (!canRun(mc, p, focused)) {
            cycleReset(mc);
            return;
        }
        updateTracking(mc, p);
        lead = leadTicks(mc, p);
    }

    public void onEndTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p != null && mc.world != null && mc.interactionManager != null
                && canRun(mc, p, Hotkey.windowFocused())) {
            decide(mc, p);
        } else {
            preArmed = false;
        }
        sprint.onEndTick(mc);
    }

    private boolean canRun(MinecraftClient mc, ClientPlayerEntity p, boolean focused) {
        return enabled && focused && mc.currentScreen == null
                && p.isAlive() && !p.isSpectator() && !p.isUsingItem();
    }

    private void decide(MinecraftClient mc, ClientPlayerEntity p) {
        boolean wasPre = preArmed;
        preArmed = false;
        if (sprint.isActive() && !wasPre) {
            return; // post-hit reset in progress
        }

        LivingEntity target = pickTarget(mc, p, lead);
        if (target == null) {
            targetId = Integer.MIN_VALUE;
            reactionLeft = -1;
            risingWaited = 0;
            return;
        }
        if (target.getId() != targetId) {
            targetId = target.getId();
            reactionLeft = -1;
            risingWaited = 0;
        }

        HitRules.PlayerState st = playerState(p);
        float cooldown = p.getAttackCooldownProgress(0.0f);
        HitRules.Verdict verdict = HitRules.decide(st, cooldown, cfg.minCooldown, risingWaited, cfg.critWaitTicks);

        if (verdict == HitRules.Verdict.WAIT) {
            if (cooldown >= cfg.minCooldown && HitRules.isRising(st)) {
                risingWaited++;
            }
            anticipateCrit(mc, p, st);
            return;
        }

        if (reactionLeft < 0) {
            reactionLeft = rollReaction();
        }
        if (reactionLeft > 0) {
            reactionLeft--;
            return;
        }

        // Crit needs "not sprinting" on the server. Fallback when the reset was not armed ahead of time:
        // release forward now, the hit follows at the end of the next tick.
        if (verdict == HitRules.Verdict.HIT_CRIT && p.isSprinting() && cfg.sprintReset && !wasPre) {
            preArmed = sprint.beginAtEnd(mc, 1, true);
            if (preArmed) {
                return;
            }
        }
        attack(mc, p, target, verdict);
    }

    /**
     * Drop sprint one tick before the crit window so the first falling tick can already hit:
     * the next tick moves the player downward (or it already falls), and the cooldown is ready by then.
     */
    private void anticipateCrit(MinecraftClient mc, ClientPlayerEntity p, HitRules.PlayerState st) {
        if (!cfg.sprintReset || !p.isSprinting() || sprint.isActive() || st.onGround() || st.critBlocked()) {
            return;
        }
        boolean fallsNext = HitRules.isFalling(st) || p.getVelocity().y < 0.0;
        if (!fallsNext || !(p.getAttackCooldownProgress(1.0f) >= cfg.minCooldown)) {
            return;
        }
        preArmed = sprint.beginAtEnd(mc, 1, true);
    }

    private void attack(MinecraftClient mc, ClientPlayerEntity p, LivingEntity target, HitRules.Verdict verdict) {
        boolean wasSprinting = p.isSprinting();
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);

        reactionLeft = -1;
        risingWaited = 0;
        if (cfg.sprintReset && verdict == HitRules.Verdict.HIT_COMBO && wasSprinting) {
            sprint.beginAtEnd(mc, cfg.sprintResetTicks, true); // W-tap after a sprint hit, sprint returns afterwards
        }
    }

    /**
     * Nearest living entity hit by the look ray within reach, on either its displayed hitbox or the
     * latency-shifted one, and not behind a block. Any part of the hitbox counts, edges included.
     */
    private LivingEntity pickTarget(MinecraftClient mc, ClientPlayerEntity p, double leadTicks) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(p.getRotationVector().multiply(cfg.reach));

        double blockDist = Double.POSITIVE_INFINITY;
        HitResult cross = mc.crosshairTarget;
        if (cross != null && cross.getType() == HitResult.Type.BLOCK) {
            blockDist = cross.getPos().distanceTo(eye);
        }

        Box area = p.getBoundingBox().expand(cfg.reach + 4.0);
        LivingEntity best = null;
        double bestDist = Double.POSITIVE_INFINITY;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, area, other -> other != p)) {
            if (!validTarget(p, e)) {
                continue;
            }
            Box shown = e.getBoundingBox().expand(cfg.hitboxMargin);
            double dist = rayDistance(shown, eye, end);
            if (leadTicks > 0.0) {
                Vec3d v = velocity.getOrDefault(e.getId(), Vec3d.ZERO);
                dist = Math.min(dist, rayDistance(shown.offset(v.multiply(leadTicks)), eye, end));
            }
            // small tolerance so a hit on the very bottom edge is not eaten by the ground block under it
            if (dist > cfg.reach || dist > blockDist + 0.05) {
                continue;
            }
            if (dist < bestDist) {
                bestDist = dist;
                best = e;
            }
        }
        return best;
    }

    private static double rayDistance(Box box, Vec3d eye, Vec3d end) {
        if (box.contains(eye)) {
            return 0.0;
        }
        Optional<Vec3d> hit = box.raycast(eye, end);
        return hit.isPresent() ? hit.get().distanceTo(eye) : Double.POSITIVE_INFINITY;
    }

    private boolean validTarget(ClientPlayerEntity p, LivingEntity e) {
        if (!e.isAlive() || e.isSpectator() || !e.isAttackable()) {
            return false;
        }
        boolean isPlayer = e instanceof PlayerEntity;
        if (isPlayer ? !cfg.targetPlayers : !cfg.targetOtherLiving) {
            return false;
        }
        if (cfg.ignoreTeammates && p.isTeammate(e)) {
            return false;
        }
        if (cfg.skipBlockingTargets && e.isBlocking()) {
            return false;
        }
        return !(cfg.ignoreInvisible && e.isInvisible());
    }

    /** Per-tick velocity (blocks/tick) of nearby entities from their displayed positions, lightly smoothed. */
    private void updateTracking(MinecraftClient mc, ClientPlayerEntity p) {
        Map<Integer, Vec3d> nextLast = new HashMap<>();
        Map<Integer, Vec3d> nextVel = new HashMap<>();
        Box area = p.getBoundingBox().expand(cfg.reach + 4.0);
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, area, other -> other != p)) {
            int id = e.getId();
            Vec3d pos = new Vec3d(e.getX(), e.getY(), e.getZ());
            Vec3d prev = lastPos.get(id);
            Vec3d v = Vec3d.ZERO;
            if (prev != null) {
                Vec3d raw = pos.subtract(prev);
                Vec3d old = velocity.getOrDefault(id, raw);
                v = old.multiply(0.5).add(raw.multiply(0.5));
                boolean finite = Double.isFinite(v.x) && Double.isFinite(v.y) && Double.isFinite(v.z);
                if (!finite || v.lengthSquared() > 4.0) {
                    v = Vec3d.ZERO; // teleport or garbage
                }
            }
            nextLast.put(id, pos);
            nextVel.put(id, v);
        }
        lastPos.clear();
        lastPos.putAll(nextLast);
        velocity.clear();
        velocity.putAll(nextVel);
    }

    private double leadTicks(MinecraftClient mc, ClientPlayerEntity p) {
        if (!cfg.latencyCompensation) {
            return 0.0;
        }
        int ping = cfg.pingOverrideMs >= 0 ? cfg.pingOverrideMs : tabListLatency(mc, p);
        return HitRules.leadTicks(ping, cfg.leadFactor, cfg.maxLeadTicks);
    }

    private static int tabListLatency(MinecraftClient mc, ClientPlayerEntity p) {
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler == null) {
            return 0;
        }
        PlayerListEntry entry = handler.getPlayerListEntry(p.getUuid());
        return entry == null ? 0 : entry.getLatency();
    }

    private static HitRules.PlayerState playerState(ClientPlayerEntity p) {
        return new HitRules.PlayerState(
                p.isOnGround(),
                p.fallDistance,
                p.isClimbing(),
                p.isTouchingWater(),
                p.hasStatusEffect(StatusEffects.BLINDNESS),
                p.hasVehicle());
    }

    private int rollReaction() {
        int lo = cfg.reactionMinTicks;
        int hi = cfg.reactionMaxTicks;
        return lo >= hi ? lo : ThreadLocalRandom.current().nextInt(lo, hi + 1);
    }

    private void cycleReset(MinecraftClient mc) {
        targetId = Integer.MIN_VALUE;
        reactionLeft = -1;
        risingWaited = 0;
        preArmed = false;
        lastPos.clear();
        velocity.clear();
        sprint.abort(mc);
    }
}
