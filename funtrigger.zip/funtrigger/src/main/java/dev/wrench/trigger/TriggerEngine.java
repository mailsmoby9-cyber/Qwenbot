package dev.wrench.trigger;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Per-tick state machine. START tick: track targets, decide (and begin a pre-hit sprint reset when needed).
 * END tick: revalidate everything and fire the vanilla attack path, the same one a click uses.
 * Targets are judged on a latency-compensated hitbox (see HitRules.leadTicks), not on the delayed crosshair.
 */
public final class TriggerEngine {
    private final TriggerConfig cfg;
    private final Hotkey hotkey = new Hotkey();
    private final SprintReset sprint = new SprintReset();

    private final Map<Integer, Vec3d> lastPos = new HashMap<>();
    private final Map<Integer, Vec3d> velocity = new HashMap<>();

    private boolean enabled;
    private double lead;
    private int targetId = Integer.MIN_VALUE;
    private int reactionLeft = -1;
    private int risingWaited;
    private boolean fireAtEnd;
    private boolean armedPre;
    private boolean postResetPending;

    public TriggerEngine(TriggerConfig cfg) {
        this.cfg = cfg;
    }

    public void onStartTick(MinecraftClient mc) {
        fireAtEnd = false;
        armedPre = false;

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            enabled = false;
            cycleReset(mc);
            return;
        }

        boolean focused = Hotkey.windowFocused();
        boolean edge = hotkey.pollEdge(cfg.toggleKey);
        if (edge && focused && mc.currentScreen == null) {
            enabled = !enabled;
            if (cfg.showToggleMessage) {
                p.sendMessage(Text.literal("Trigger: " + (enabled ? "ON" : "OFF")), true);
            }
        }

        sprint.onStartTick(mc, p);

        if (!enabled || !focused || mc.currentScreen != null
                || !p.isAlive() || p.isSpectator() || p.isUsingItem()) {
            cycleReset(mc);
            return;
        }

        updateTracking(mc, p);
        lead = leadTicks(mc, p);

        if (postResetPending) {
            postResetPending = false;
            sprint.begin(mc, cfg.sprintResetTicks, true);
        }
        if (sprint.isActive()) {
            return; // a reset is running, no new cycle until forward is given back
        }

        LivingEntity target = pickTarget(mc, p, lead);
        if (target == null) {
            targetId = Integer.MIN_VALUE;
            reactionLeft = -1;
            risingWaited = 0;
            return;
        }
        if (target.getId() != targetId) {
            targetId = target.getId();
            reactionLeft = -1;
            risingWaited = 0;
        }

        HitRules.PlayerState st = playerState(p);
        float cooldown = p.getAttackCooldownProgress(0.0f);
        HitRules.Verdict verdict = HitRules.decide(st, cooldown, cfg.minCooldown, risingWaited, cfg.critWaitTicks);
        if (verdict == HitRules.Verdict.WAIT) {
            if (cooldown >= cfg.minCooldown && HitRules.isRising(st)) {
                risingWaited++;
            }
            return;
        }

        if (reactionLeft < 0) {
            reactionLeft = rollReaction();
        }
        if (reactionLeft > 0) {
            reactionLeft--;
            return;
        }

        // Crit needs "not sprinting" on the server: release forward this tick, hit at the END of it.
        if (verdict == HitRules.Verdict.HIT_CRIT && p.isSprinting() && cfg.sprintReset
                && sprint.begin(mc, 1, true)) {
            armedPre = true;
            return;
        }
        fireAtEnd = true;
    }

    public void onEndTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        boolean fire = fireAtEnd || armedPre;
        fireAtEnd = false;
        armedPre = false;
        if (p != null && mc.interactionManager != null && fire) {
            tryAttack(mc, p);
        }
        sprint.onEndTick(mc);
    }

    private void tryAttack(MinecraftClient mc, ClientPlayerEntity p) {
        if (!enabled || !Hotkey.windowFocused() || mc.currentScreen != null
                || !p.isAlive() || p.isUsingItem()) {
            return;
        }
        LivingEntity target = pickTarget(mc, p, lead);
        if (target == null || target.getId() != targetId) {
            return;
        }
        HitRules.Verdict verdict = HitRules.decide(playerState(p), p.getAttackCooldownProgress(0.0f),
                cfg.minCooldown, risingWaited, cfg.critWaitTicks);
        if (verdict == HitRules.Verdict.WAIT) {
            return;
        }

        boolean wasSprinting = p.isSprinting();
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);

        reactionLeft = -1;
        risingWaited = 0;
        if (cfg.sprintReset && verdict == HitRules.Verdict.HIT_COMBO && wasSprinting) {
            postResetPending = true; // W-tap after a sprint hit, sprint comes back afterwards
        }
    }

    /** Nearest living entity whose latency-shifted hitbox is on the look ray within reach and not behind a block. */
    private LivingEntity pickTarget(MinecraftClient mc, ClientPlayerEntity p, double leadTicks) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(p.getRotationVector().multiply(cfg.reach));

        double blockDist = Double.POSITIVE_INFINITY;
        HitResult cross = mc.crosshairTarget;
        if (cross != null && cross.getType() == HitResult.Type.BLOCK) {
            blockDist = cross.getPos().distanceTo(eye);
        }

        Box area = p.getBoundingBox().expand(cfg.reach + 4.0);
        LivingEntity best = null;
        double bestDist = Double.POSITIVE_INFINITY;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, area, other -> other != p)) {
            if (!validTarget(p, e)) {
                continue;
            }
            Vec3d v = velocity.getOrDefault(e.getId(), Vec3d.ZERO);
            Box box = e.getBoundingBox().offset(v.multiply(leadTicks));
            double dist;
            if (box.contains(eye)) {
                dist = 0.0;
            } else {
                Optional<Vec3d> hit = box.raycast(eye, end);
                if (hit.isEmpty()) {
                    continue;
                }
                dist = hit.get().distanceTo(eye);
            }
            if (dist > cfg.reach || dist >= blockDist) {
                continue;
            }
            if (dist < bestDist) {
                bestDist = dist;
                best = e;
            }
        }
        return best;
    }

    private boolean validTarget(ClientPlayerEntity p, LivingEntity e) {
        if (!e.isAlive() || e.isSpectator() || !e.isAttackable()) {
            return false;
        }
        boolean isPlayer = e instanceof PlayerEntity;
        if (isPlayer ? !cfg.targetPlayers : !cfg.targetOtherLiving) {
            return false;
        }
        if (cfg.ignoreTeammates && p.isTeammate(e)) {
            return false;
        }
        if (cfg.skipBlockingTargets && e.isBlocking()) {
            return false;
        }
        return !(cfg.ignoreInvisible && e.isInvisible());
    }

    /** Per-tick velocity (blocks/tick) of nearby entities from their displayed positions, lightly smoothed. */
    private void updateTracking(MinecraftClient mc, ClientPlayerEntity p) {
        Map<Integer, Vec3d> nextLast = new HashMap<>();
        Map<Integer, Vec3d> nextVel = new HashMap<>();
        Box area = p.getBoundingBox().expand(cfg.reach + 4.0);
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, area, other -> other != p)) {
            int id = e.getId();
            Vec3d pos = new Vec3d(e.getX(), e.getY(), e.getZ());
            Vec3d prev = lastPos.get(id);
            Vec3d v = Vec3d.ZERO;
            if (prev != null) {
                Vec3d raw = pos.subtract(prev);
                Vec3d old = velocity.getOrDefault(id, raw);
                v = old.multiply(0.5).add(raw.multiply(0.5));
                boolean finite = Double.isFinite(v.x) && Double.isFinite(v.y) && Double.isFinite(v.z);
                if (!finite || v.lengthSquared() > 4.0) {
                    v = Vec3d.ZERO; // teleport or garbage
                }
            }
            nextLast.put(id, pos);
            nextVel.put(id, v);
        }
        lastPos.clear();
        lastPos.putAll(nextLast);
        velocity.clear();
        velocity.putAll(nextVel);
    }

    private double leadTicks(MinecraftClient mc, ClientPlayerEntity p) {
        if (!cfg.latencyCompensation) {
            return 0.0;
        }
        int ping = cfg.pingOverrideMs >= 0 ? cfg.pingOverrideMs : tabListLatency(mc, p);
        return HitRules.leadTicks(ping, cfg.leadFactor, cfg.maxLeadTicks);
    }

    private static int tabListLatency(MinecraftClient mc, ClientPlayerEntity p) {
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler == null) {
            return 0;
        }
        PlayerListEntry entry = handler.getPlayerListEntry(p.getUuid());
        return entry == null ? 0 : entry.getLatency();
    }

    private static HitRules.PlayerState playerState(ClientPlayerEntity p) {
        return new HitRules.PlayerState(
                p.isOnGround(),
                p.fallDistance,
                p.isClimbing(),
                p.isTouchingWater(),
                p.hasStatusEffect(StatusEffects.BLINDNESS),
                p.hasVehicle());
    }

    private int rollReaction() {
        int lo = cfg.reactionMinTicks;
        int hi = cfg.reactionMaxTicks;
        return lo >= hi ? lo : ThreadLocalRandom.current().nextInt(lo, hi + 1);
    }

    private void cycleReset(MinecraftClient mc) {
        targetId = Integer.MIN_VALUE;
        reactionLeft = -1;
        risingWaited = 0;
        fireAtEnd = false;
        armedPre = false;
        postResetPending = false;
        lastPos.clear();
        velocity.clear();
        sprint.abort(mc);
    }
}
