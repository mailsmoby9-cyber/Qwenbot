package dev.tb;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

/**
 * START_CLIENT_TICK  — решение: будет ли этот удар критом, и если да, отпускаем спринт.
 * END_CLIENT_TICK    — удар (после movement-пакета, поэтому сервер видит STOP раньше).
 * END_MAIN (кадр)    — только заведомо не-критовые удары, суб-тик реакция.
 *
 * Ни одного sendPacket. Спринт снимается только под реальный крит в падении.
 */
public final class TriggerEngine {

    private static final double RAD = Math.PI / 180.0;
    private static final double AIM_SLACK = 0.12;
    private static final double MAX_RAY = 6.0;
    private static final int MIN_GAP = 2;
    private static final int IFRAME_GAP = 10;

    private static boolean enabled, keyWasDown;
    private static int tick;
    private static ClientWorld world;

    private static int lockedId = -1, lockedAt;
    private static int attackTick = -1000;
    private static int lastHitId = -1, lastHitTick = -1000;
    private static boolean critArmed;
    private static String reason = "idle";

    private TriggerEngine() {}

    static boolean isEnabled() { return enabled; }

    static String reason() { return reason; }

    static void toggle() { setEnabled(!enabled); }

    static void setEnabled(boolean on) {
        if (enabled == on) return;
        enabled = on;
        MinecraftClient mc = MinecraftClient.getInstance();
        VanillaInput.reset(mc);
        clearTarget();
        critArmed = false;
        reason = on ? "ready" : "idle";
        Hud.state(on, reason);
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(on ? "TriggerBot: ON" : "TriggerBot: OFF")
                    .formatted(on ? Formatting.GREEN : Formatting.RED), true);
        }
    }

    static void onDisconnect() {
        setEnabled(false);
        hardReset(MinecraftClient.getInstance());
    }

    private static void hardReset(MinecraftClient mc) {
        VanillaInput.reset(mc);
        clearTarget();
        critArmed = false;
        attackTick = tick - 1000;
        lastHitId = -1;
        lastHitTick = tick - 1000;
    }

    private static void clearTarget() { lockedId = -1; }

    /** До movement-пакета. */
    static void beginTick(MinecraftClient mc) {
        tick++;
        VanillaInput.beginTick(mc);
        pollKey(mc);

        ClientWorld w = mc.world;
        if (w != world) { world = w; hardReset(mc); }

        critArmed = false;
        Config c = Config.get();
        if (!enabled || !c.crit || !ready(mc)) return;

        ClientPlayerEntity p = mc.player;
        Entity e = Mc.crosshairEntity(mc);
        if (e == null || !valid(mc, p, e)) return;
        if (tick - lockedAt < c.lockTicks) return;
        if (e.getId() == lastHitId && tick - lastHitTick < IFRAME_GAP) return;
        if (p.isUsingItem()) return;

        // Прогноз на конец тика: заряд дозреет и мы будем в фазе падения.
        if (Mc.charge(p) + Mc.chargePerTick(p) < c.charge) return;
        if (p.isOnGround() || p.getVelocity().y >= 0.0) return;
        if (!Mc.critEnvironment(p) || Mc.willLand(mc, p)) return;

        if (p.isSprinting()) {
            critArmed = VanillaInput.suppressSprint(mc);
        } else {
            critArmed = true;   // спринт и так выключен — крит пройдёт сам
        }
        if (critArmed) { reason = "crit-armed"; Hud.state(true, reason); }
    }

    /** После movement-пакета. */
    static void endTick(MinecraftClient mc) {
        if (!enabled) return;
        evaluate(mc, true);
    }

    /** Кадровый путь: быстрее тика, но криты не ворует. */
    static void frame(MinecraftClient mc) {
        if (!enabled || !Config.get().fast || critArmed) return;
        evaluate(mc, false);
    }

    private static void evaluate(MinecraftClient mc, boolean tickMode) {
        if (!ready(mc)) { clearTarget(); reason = "no-world"; return; }
        ClientPlayerEntity p = mc.player;
        if (mc.getCameraEntity() != p || !p.isAlive() || p.isSpectator()) { clearTarget(); reason = "camera"; return; }

        Entity e = Mc.crosshairEntity(mc);
        if (e == null || !valid(mc, p, e)) { clearTarget(); reason = "no-target"; return; }

        Config c = Config.get();
        int id = e.getId();
        if (id != lockedId) { lockedId = id; lockedAt = tick; }
        if (tick - lockedAt < c.lockTicks) { reason = "lock"; return; }
        if (tick - attackTick < MIN_GAP) { reason = "gap"; return; }
        if (id == lastHitId && tick - lastHitTick < IFRAME_GAP) { reason = "iframes"; return; }
        if (p.isUsingItem()) { reason = "using-item"; return; }
        if (Mc.charge(p) < c.charge) { reason = "charge"; return; }
        if (tickMode && c.strictAim && !aimOnTarget(p, e.getBoundingBox())) { reason = "aim"; return; }

        boolean falling = Mc.falling(p) && Mc.critEnvironment(p);
        if (!tickMode && c.crit && falling) { reason = "crit-pending"; return; }

        Mc.attack(mc, p, e);
        attackTick = tick;
        lastHitId = id;
        lastHitTick = tick;

        boolean crit = falling && !p.isSprinting();
        reason = crit ? "crit" : (p.isSprinting() ? "sprint-hit" : "hit");
        Hud.state(true, reason);
    }

    private static boolean ready(MinecraftClient mc) {
        return mc.world != null && mc.player != null && mc.interactionManager != null
                && mc.getNetworkHandler() != null && mc.currentScreen == null && !mc.isPaused();
    }

    private static void pollKey(MinecraftClient mc) {
        if (mc.currentScreen != null) { keyWasDown = true; return; }
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), Config.get().toggleKey) == GLFW.GLFW_PRESS;
        if (down && !keyWasDown) toggle();
        keyWasDown = down;
    }

    private static boolean valid(MinecraftClient mc, ClientPlayerEntity p, Entity e) {
        if (e == p || !(e instanceof LivingEntity le)) return false;
        if (e.isRemoved() || !e.isAlive() || le.getHealth() <= 0.0f) return false;
        if (e instanceof ArmorStandEntity) return false;

        Config c = Config.get();
        if (e instanceof PlayerEntity pe) {
            if (c.targetMode == 1) return false;                 // hostile: игроков не бьём
            if (Mc.protectedMode(mc, pe, c.ignoreCreative)) return false;
            if (c.ignoreTeammates && Mc.sameTeam(p, pe)) return false;
        } else {
            if (c.targetMode == 0) return false;                 // players: только игроки
            if (c.targetMode == 1 && !(e instanceof HostileEntity)) return false;
        }

        if (c.ignoreInvisible && e.isInvisible()) return false;
        if (c.rangeSq > 0.0 && boxDistSq(p, e) > c.rangeSq) return false;
        return true;
    }

    private static double boxDistSq(Entity from, Entity to) {
        double x = from.getX(), y = from.getEyeY(), z = from.getZ();
        Box b = to.getBoundingBox();
        double dx = Math.max(0.0, Math.max(b.minX - x, x - b.maxX));
        double dy = Math.max(0.0, Math.max(b.minY - y, y - b.maxY));
        double dz = Math.max(0.0, Math.max(b.minZ - z, z - b.maxZ));
        return dx * dx + dy * dy + dz * dz;
    }

    /** Slab-тест луч/бокс по текущему yaw/pitch. Ноль объектов. */
    private static boolean aimOnTarget(ClientPlayerEntity p, Box b) {
        double yaw = p.getYaw() * RAD, pitch = p.getPitch() * RAD;
        double cp = Math.cos(pitch);
        double dx = -Math.sin(yaw) * cp, dy = -Math.sin(pitch), dz = Math.cos(yaw) * cp;
        double ox = p.getX(), oy = p.getEyeY(), oz = p.getZ();
        double tMin = 0.0, tMax = MAX_RAY;

        double min = b.minX - AIM_SLACK, max = b.maxX + AIM_SLACK;
        if (Math.abs(dx) < 1.0E-7) { if (ox < min || ox > max) return false; }
        else {
            double t1 = (min - ox) / dx, t2 = (max - ox) / dx;
            if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
            if (t1 > tMin) tMin = t1;
            if (t2 < tMax) tMax = t2;
            if (tMin > tMax) return false;
        }

        min = b.minY - AIM_SLACK; max = b.maxY + AIM_SLACK;
        if (Math.abs(dy) < 1.0E-7) { if (oy < min || oy > max) return false; }
        else {
            double t1 = (min - oy) / dy, t2 = (max - oy) / dy;
            if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
            if (t1 > tMin) tMin = t1;
            if (t2 < tMax) tMax = t2;
            if (tMin > tMax) return false;
        }

        min = b.minZ - AIM_SLACK; max = b.maxZ + AIM_SLACK;
        if (Math.abs(dz) < 1.0E-7) { if (oz < min || oz > max) return false; }
        else {
            double t1 = (min - oz) / dz, t2 = (max - oz) / dz;
            if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
            if (t1 > tMin) tMin = t1;
            if (t2 < tMax) tMax = t2;
            if (tMin > tMax) return false;
        }
        return true;
    }
}
