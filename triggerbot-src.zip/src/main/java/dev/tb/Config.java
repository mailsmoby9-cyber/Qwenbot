package dev.tb;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {

    private static final Logger LOG = LoggerFactory.getLogger("triggerbot");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("triggerbot.json");
    private static final Config INSTANCE = load();

    public boolean hud = true;
    public boolean fast = true;            // суб-тик реакция
    public boolean crit = true;            // отпускать спринт на 1 тик под реальный крит
    public boolean strictAim = true;
    public boolean ignoreCreative = true;
    public boolean ignoreTeammates = true;
    public boolean ignoreInvisible = false;

    public int chargePercent = 100;        // 91..100: ниже 91 крит и спринт-бонус не работают
    public int lockTicks = 0;              // 0..5
    public double range = 0.0;             // 0 = ванильный reach
    public int toggleKey = GLFW.GLFW_KEY_R;
    public String targets = "players";     // players | hostile | all

    public transient float charge = 1.0f;
    public transient double rangeSq = 0.0;
    public transient int targetMode = 0;

    private Config() {}

    public static Config get() { return INSTANCE; }

    private static Config load() {
        Config c = null;
        if (Files.isRegularFile(FILE)) {
            try (BufferedReader r = Files.newBufferedReader(FILE)) {
                c = GSON.fromJson(r, Config.class);
            } catch (Exception e) {
                LOG.warn("[triggerbot] конфиг не читается (старый формат?) — значения по умолчанию", e);
            }
        }
        if (c == null) c = new Config();
        c.sanitize();
        c.save();
        return c;
    }

    public void sanitize() {
        chargePercent = clamp(chargePercent, 91, 100);
        lockTicks = clamp(lockTicks, 0, 5);
        toggleKey = clamp(toggleKey, 32, 348);
        range = Math.max(0.0, Math.min(6.0, range));
        if (targets == null) targets = "players";
        switch (targets) {
            case "hostile" -> targetMode = 1;
            case "all" -> targetMode = 2;
            default -> { targets = "players"; targetMode = 0; }
        }
        charge = chargePercent / 100.0f;
        rangeSq = range * range;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (BufferedWriter w = Files.newBufferedWriter(FILE)) {
                GSON.toJson(this, w);
            }
        } catch (Exception e) {
            LOG.warn("[triggerbot] не удалось сохранить конфиг", e);
        }
    }

    private static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
}
