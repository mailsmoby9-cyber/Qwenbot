package dev.tb;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.GameMode;

/** Версионно-чувствительный слой. Маппинг уехал — правки только здесь. */
final class Mc {

    private Mc() {}

    static Entity crosshairEntity(MinecraftClient mc) {
        return mc.crosshairTarget instanceof EntityHitResult hit ? hit.getEntity() : null;
    }

    static float charge(PlayerEntity p) { return p.getAttackCooldownProgress(0.5f); }

    static float chargePerTick(PlayerEntity p) { return p.getAttackCooldownProgressPerTick(); }

    /** Ваниль свингует всегда — свинг не пропускаем никогда. */
    static void attack(MinecraftClient mc, ClientPlayerEntity p, Entity target) {
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    static boolean protectedMode(MinecraftClient mc, PlayerEntity p, boolean ignoreCreative) {
        var nh = mc.getNetworkHandler();
        if (nh == null) return false;
        var entry = nh.getPlayerListEntry(p.getUuid());
        if (entry == null) return false;
        GameMode mode = entry.getGameMode();
        return mode == GameMode.SPECTATOR || (ignoreCreative && mode == GameMode.CREATIVE);
    }

    static boolean sameTeam(Entity a, Entity b) {
        var team = a.getScoreboardTeam();
        return team != null && team == b.getScoreboardTeam();
    }

    /** Падение, которое сервер видит из movement-пакета. */
    static boolean falling(LivingEntity e) {
        return !e.isOnGround() && e.getVelocity().y < 0.0 && e.fallDistance > 0.0;
    }

    static boolean critEnvironment(LivingEntity e) {
        return !e.isTouchingWater()
                && !e.isInLava()
                && !e.isClimbing()
                && !e.hasVehicle()
                && !e.isGliding()
                && !e.hasStatusEffect(StatusEffects.BLINDNESS);
    }

    /** Приземлимся на этом тике? Тогда крит не пройдёт — спринт не трогаем. */
    static boolean willLand(MinecraftClient mc, ClientPlayerEntity p) {
        double dy = Math.min(0.0, p.getVelocity().y);
        return !mc.world.isSpaceEmpty(p, p.getBoundingBox().offset(0.0, dy - 1.0E-4, 0.0));
    }
}
