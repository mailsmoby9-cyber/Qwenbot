package dev.tb;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

/**
 * Единственное место, где мод трогает ввод. Пакетов не отправляет вообще.
 *
 * Сброс спринта = отпускание клавиши ровно на один тик. Дальше всё делает ваниль:
 * tickMovement снимает спринт, sendSprintingPacket сам шлёт STOP, на следующем
 * тике клавиша возвращена в физическое состояние и ваниль сама шлёт START.
 *
 * Версионно-чувствительные строки: options.sprintKey, setPressed, updatePressedStates.
 */
final class VanillaInput {

    private static boolean suppressed;

    private VanillaInput() {}

    static boolean isSuppressed() { return suppressed; }

    /** Начало тика: если отпускали на прошлом — возвращаем клавишу. */
    static void beginTick(MinecraftClient mc) {
        if (suppressed) restore(mc);
    }

    /** Отпустить спринт на текущий тик. true — если реально отпустили. */
    static boolean suppressSprint(MinecraftClient mc) {
        if (suppressed) return true;
        if (mc.player == null || !mc.player.isSprinting()) return false;
        KeyBinding key = mc.options.sprintKey;
        // Не нажата, а спринт активен -> toggle-режим или чужой источник. Не лезем.
        if (!key.isPressed()) return false;
        key.setPressed(false);
        suppressed = true;
        return true;
    }

    /** Возврат строго в физическое состояние: отпустил руками — не залипаем. */
    static void restore(MinecraftClient mc) {
        if (!suppressed) return;
        suppressed = false;
        KeyBinding.updatePressedStates();
    }

    static void reset(MinecraftClient mc) { restore(mc); }
}
