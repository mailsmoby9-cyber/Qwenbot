package dev.tb;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

public final class TriggerBotClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        Config.get();
        Commands.register();

        // START: до movement-пакета. Здесь принимается решение про спринт.
        ClientTickEvents.START_CLIENT_TICK.register(TriggerEngine::beginTick);
        // END: после movement-пакета. Здесь уходит удар.
        ClientTickEvents.END_CLIENT_TICK.register(TriggerEngine::endTick);

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> TriggerEngine.onDisconnect());

        // Суб-тик путь не зависит от видимости HUD.
        WorldRenderEvents.END_MAIN.register(ctx -> TriggerEngine.frame(MinecraftClient.getInstance()));

        HudElementRegistry.addLast(Identifier.of("triggerbot", "hud"), (ctx, tickCounter) -> Hud.render(ctx));
    }
}
