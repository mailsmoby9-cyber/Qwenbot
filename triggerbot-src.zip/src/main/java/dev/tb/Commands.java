package dev.tb;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;

final class Commands {

    private Commands() {}

    static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> {
            dispatcher.register(build("triggerbot"));
            dispatcher.register(build("tb"));
        });
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> build(String name) {
        return ClientCommandManager.literal(name)
                .executes(ctx -> { TriggerEngine.toggle(); return 1; })
                .then(ClientCommandManager.literal("on")
                        .executes(ctx -> { TriggerEngine.setEnabled(true); return 1; }))
                .then(ClientCommandManager.literal("off")
                        .executes(ctx -> { TriggerEngine.setEnabled(false); return 1; }))
                .then(ClientCommandManager.literal("status")
                        .executes(ctx -> status(ctx.getSource())))
                .then(ClientCommandManager.literal("set")
                        .then(ClientCommandManager.argument("option", StringArgumentType.word())
                                .then(ClientCommandManager.argument("value", StringArgumentType.word())
                                        .executes(ctx -> set(ctx.getSource(),
                                                StringArgumentType.getString(ctx, "option"),
                                                StringArgumentType.getString(ctx, "value"))))));
    }

    private static int status(FabricClientCommandSource src) {
        Config c = Config.get();
        msg(src, "TriggerBot: " + (TriggerEngine.isEnabled() ? "ON" : "OFF")
                + "  last=" + TriggerEngine.reason()
                + "  sprintKeyHeld=" + VanillaInput.isSuppressed());
        msg(src, "crit=" + c.crit + "  charge=" + c.chargePercent + "%  fast=" + c.fast + "  aim=" + c.strictAim);
        msg(src, "lock=" + c.lockTicks + "  range=" + c.range + "  targets=" + c.targets);
        msg(src, "hud=" + c.hud + "  key=" + c.toggleKey + "  creative=" + c.ignoreCreative
                + "  team=" + c.ignoreTeammates + "  invisible=" + c.ignoreInvisible);
        return 1;
    }

    private static int set(FabricClientCommandSource src, String opt, String val) {
        Config c = Config.get();
        try {
            switch (opt.toLowerCase()) {
                case "crit"      -> c.crit = bool(val);
                case "charge"    -> c.chargePercent = Integer.parseInt(val);
                case "lock"      -> c.lockTicks = Integer.parseInt(val);
                case "range"     -> c.range = Double.parseDouble(val);
                case "targets"   -> c.targets = val.toLowerCase();
                case "fast"      -> c.fast = bool(val);
                case "hud"       -> c.hud = bool(val);
                case "aim"       -> c.strictAim = bool(val);
                case "creative"  -> c.ignoreCreative = bool(val);
                case "team"      -> c.ignoreTeammates = bool(val);
                case "invisible" -> c.ignoreInvisible = bool(val);
                case "key"       -> c.toggleKey = key(val);
                default -> { msg(src, "Нет такой опции: " + opt); return 0; }
            }
        } catch (Exception ex) {
            msg(src, "Некорректное значение: " + val);
            return 0;
        }
        c.sanitize();
        c.save();
        msg(src, opt + " = " + val);
        return 1;
    }

    private static boolean bool(String v) {
        if (v.equalsIgnoreCase("on") || v.equalsIgnoreCase("true") || v.equals("1")) return true;
        if (v.equalsIgnoreCase("off") || v.equalsIgnoreCase("false") || v.equals("0")) return false;
        throw new IllegalArgumentException(v);
    }

    private static int key(String v) {
        if (v.length() == 1) {
            char ch = Character.toUpperCase(v.charAt(0));
            if (ch >= 'A' && ch <= 'Z') return ch;
            if (ch >= '0' && ch <= '9') return ch;
        }
        return Integer.parseInt(v);
    }

    private static void msg(FabricClientCommandSource src, String s) {
        src.sendFeedback(Text.literal("[TB] " + s));
    }
}
