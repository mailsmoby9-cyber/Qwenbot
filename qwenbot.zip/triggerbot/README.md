# TriggerBot — Fabric 1.21.11 / Java 21

Клиентский модуль. R — вкл/выкл, /tb — управление из чата.

## Сборка
GitHub -> Actions -> build -> Run workflow -> Artifacts -> triggerbot-full (ZIP с jar и исходниками).
Wrapper не нужен: CI собирает системным Gradle, версии Yarn/Loader/Fabric API/Loom
подбираются автоматически скриптом .github/resolve_versions.py.

## Установка
Fabric Loader 1.21.11 + Fabric API + triggerbot-*.jar в .minecraft/mods/. Java 21.

## Команды
/tb · /tb on · /tb off · /tb status · /tb set <опция> <значение>

crit      off / wait / auto   (auto)
lead      3-10                (7)
wait      0-12                (8)
charge    50-100              (100)
sprint    on/off              (on)
fast      on/off              (on)
aim       on/off              (on)
lock      0-5                 (0)
range     0-6                 (0)
targets   players/hostile/all (players)
hud       on/off              (on)
key       буква или GLFW-код  (R)

## Режимы крита
auto — упреждающий прыжок за lead тиков до заряда, удар в фазе падения.
wait — не прыгает, ждёт крит-окна до wait тиков, если ты уже в воздухе.
off  — бьёт сразу, как только заряд готов.

Крит и спринт совмещены: перед крит-ударом серверу уходит STOP_SPRINTING,
на следующем тике — START_SPRINTING. Клиентская скорость не проседает.

## Если что-то не так
Криты не проходят: /tb set lead 8, /tb set wait 10.
Прыжки мешают: /tb set crit wait.
Ошибка компиляции: правь только src/main/java/dev/tb/Mc.java — весь
версионно-чувствительный код собран там.
