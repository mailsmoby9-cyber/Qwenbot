#!/usr/bin/env python3
"""Подбирает актуальные yarn / loader / Fabric API / Loom под minecraft_version."""
import json, os, re, sys, urllib.parse, urllib.request
from pathlib import Path

PROPS = Path("gradle.properties")


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "triggerbot-ci/1.0"})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read().decode("utf-8")


def main():
    text = PROPS.read_text(encoding="utf-8")

    def prop(key):
        m = re.search(rf"^{key}\s*=\s*(.+)$", text, re.M)
        return m.group(1).strip() if m else ""

    mc = prop("minecraft_version")
    if not mc:
        sys.exit("minecraft_version не задан в gradle.properties")
    print("Minecraft:", mc)
    upd = {}

    try:
        data = json.loads(get(f"https://meta.fabricmc.net/v2/versions/yarn/{mc}"))
        if data:
            v = data[0]
            upd["yarn_mappings"] = v.get("version") or f'{mc}+build.{v["build"]}'
    except Exception as e:
        print("yarn: FAIL", e)

    try:
        data = json.loads(get("https://meta.fabricmc.net/v2/versions/loader"))
        stable = [v for v in data if v.get("stable")]
        upd["loader_version"] = (stable or data)[0]["version"]
    except Exception as e:
        print("loader: FAIL", e)

    try:
        q = urllib.parse.urlencode({
            "game_versions": json.dumps([mc]),
            "loaders": json.dumps(["fabric"]),
        })
        data = json.loads(get(f"https://api.modrinth.com/v2/project/fabric-api/version?{q}"))
        data = [v for v in data if mc in v["game_versions"] and "fabric" in v["loaders"]]
        data.sort(key=lambda v: v["date_published"], reverse=True)
        if data:
            upd["fabric_version"] = data[0]["version_number"]
    except Exception as e:
        print("fabric-api: FAIL", e)

    override = os.environ.get("LOOM_OVERRIDE", "").strip()
    if override:
        upd["loom_version"] = override
    else:
        try:
            xml = get("https://maven.fabricmc.net/net/fabricmc/fabric-loom/maven-metadata.xml")
            snaps = [v for v in re.findall(r"<version>([^<]+)</version>", xml)
                     if re.fullmatch(r"\d+\.\d+-SNAPSHOT", v)]
            if snaps:
                upd["loom_version"] = max(
                    snaps, key=lambda v: tuple(int(x) for x in v.split("-")[0].split(".")))
        except Exception as e:
            print("loom: FAIL", e)

    for k, v in upd.items():
        text = re.sub(rf"^{k}\s*=.*$", f"{k}={v}", text, flags=re.M)
        print(f"{k} = {v}")
    PROPS.write_text(text, encoding="utf-8")

    if "yarn_mappings" not in upd:
        print(f"::warning::Yarn для {mc} не найден в meta.fabricmc.net — "
              f"проверь правильность minecraft_version")


main()
