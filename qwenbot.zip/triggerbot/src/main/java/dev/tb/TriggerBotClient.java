package dev.tb;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

public final class TriggerBotClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        Config.get();
        Commands.register();

        // Тиковый путь — основной, крит-удары только отсюда.
        ClientTickEvents.END_CLIENT_TICK.register(TriggerEngine::tick);

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> TriggerEngine.onDisconnect());

        // Кадровый путь (суб-тик реакция) + индикатор.
        // Если HUD скрыт (F1) и колбэк не вызывается — тиковый путь продолжает работать.
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            TriggerEngine.frame(MinecraftClient.getInstance());
            Hud.render(drawContext);
        });
    }
}
