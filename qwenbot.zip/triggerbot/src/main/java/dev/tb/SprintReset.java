package dev.tb;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Один автомат на два сценария.
 *
 *  КРИТ:  тик T   -> STOP_SPRINTING, сразу за ним ATTACK (один канал, порядок гарантирован)
 *         тик T+1 -> START_SPRINTING
 *         Сервер видит "не спринтует" в момент удара -> крит проходит.
 *
 *  КОМБО: тик T   -> ATTACK (спринт-удар = доп. отбрасывание, сервер сбрасывает спринт)
 *         тик T+1 -> STOP_SPRINTING
 *         тик T+2 -> START_SPRINTING (перерегистрация, следующий удар снова с бонусом)
 *
 * Клиентский спринт не меняется никогда -> скорость движения не проседает.
 * Watchdog + гарантированный START при любом срыве -> десинхрон невозможен.
 */
final class SprintReset {

    private static final int IDLE = 0, STOP = 1, START = 2;
    private static final int WATCHDOG = 4;

    private static int state = IDLE;
    private static int at;
    private static boolean stopSent;
    private static boolean forCrit;

    private SprintReset() {}

    /** Вызывается СТРОГО перед пакетом атаки, если удар критовый. */
    static void dropForCrit(MinecraftClient mc, ClientPlayerEntity p, int tick) {
        if (mc.getNetworkHandler() == null || !p.isSprinting()) return;
        Mc.sprint(mc, false);
        stopSent = true;
        state = START;
        at = tick;
        forCrit = true;
    }

    /** Обычный сброс спринта после некритового удара. */
    static void afterAttack(MinecraftClient mc, ClientPlayerEntity p, int tick) {
        if (state != IDLE || !Config.get().sprintReset) return;
        if (!p.isSprinting() || mc.getNetworkHandler() == null) return;
        state = STOP;
        at = tick;
        forCrit = false;
    }

    static void tick(MinecraftClient mc, boolean enabled, int tick) {
        if (state == IDLE) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.getNetworkHandler() == null) { reset(); return; }
        if (!enabled || (!forCrit && !Config.get().sprintReset) || tick - at > WATCHDOG) {
            finish(mc);
            return;
        }
        if (state == STOP) {
            if (p.isSprinting()) { Mc.sprint(mc, false); stopSent = true; }
            state = START;
            at = tick;
        } else {
            if (p.isSprinting()) Mc.sprint(mc, true);
            reset();
        }
    }

    /** Если STOP ушёл — START обязателен, иначе сервер останется "не спринтует". */
    static void finish(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (stopSent && p != null && p.isSprinting() && mc.getNetworkHandler() != null) {
            Mc.sprint(mc, true);
        }
        reset();
    }

    static void reset() {
        state = IDLE;
        stopSent = false;
        forCrit = false;
    }
}
