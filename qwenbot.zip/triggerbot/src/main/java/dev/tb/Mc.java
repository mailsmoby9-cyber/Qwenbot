package dev.tb;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.GameMode;

/**
 * ЕДИНСТВЕННЫЙ версионно-чувствительный слой.
 * Сломается маппинг — правки только здесь.
 */
final class Mc {

    private Mc() {}

    static Entity crosshairEntity(MinecraftClient mc) {
        return mc.crosshairTarget instanceof EntityHitResult hit ? hit.getEntity() : null;
    }

    static float charge(PlayerEntity p) {
        return p.getAttackCooldownProgress(0.5f);
    }

    static void attack(MinecraftClient mc, ClientPlayerEntity p, Entity target) {
        mc.interactionManager.attackEntity(p, target);
        if (!p.handSwinging) p.swingHand(Hand.MAIN_HAND);
    }

    /** Серверное состояние спринта. Клиентский спринт (скорость) НЕ трогаем. */
    static void sprint(MinecraftClient mc, boolean on) {
        var nh = mc.getNetworkHandler();
        if (nh == null || mc.player == null) return;
        nh.sendPacket(new ClientCommandC2SPacket(mc.player,
                on ? ClientCommandC2SPacket.Mode.START_SPRINTING
                   : ClientCommandC2SPacket.Mode.STOP_SPRINTING));
    }

    static boolean protectedMode(MinecraftClient mc, PlayerEntity p, boolean ignoreCreative) {
        var nh = mc.getNetworkHandler();
        if (nh == null) return false;
        var entry = nh.getPlayerListEntry(p.getUuid());
        if (entry == null) return false;
        GameMode mode = entry.getGameMode();
        return mode == GameMode.SPECTATOR || (ignoreCreative && mode == GameMode.CREATIVE);
    }

    static boolean sameTeam(Entity a, Entity b) {
        var team = a.getScoreboardTeam();
        return team != null && team == b.getScoreboardTeam();
    }

    /** Фаза падения — то, что сервер видит из movement-пакета. */
    static boolean falling(LivingEntity e) {
        return !e.isOnGround() && e.getVelocity().y < 0.0 && e.fallDistance > 0.0F;
    }

    /** Условия крита, кроме спринта: спринт снимается пакетом прямо перед ударом. */
    static boolean critEnvironment(LivingEntity e) {
        return !e.isTouchingWater()
                && !e.isInLava()
                && !e.isClimbing()
                && !e.hasVehicle()
                && !e.isFallFlying()
                && !e.hasStatusEffect(StatusEffects.BLINDNESS);
    }

    /** Крит ещё возможен в ближайшие тики (в воздухе, состояние не блокирует). */
    static boolean critSoon(LivingEntity e) {
        return !e.isOnGround()
                && !e.isTouchingWater()
                && !e.isInLava()
                && !e.isClimbing()
                && !e.hasVehicle()
                && !e.isFallFlying();
    }

    /** Свободно ли место над головой для прыжка (~1.25 блока). */
    static boolean spaceAbove(MinecraftClient mc, ClientPlayerEntity p) {
        return mc.world.isSpaceEmpty(p, p.getBoundingBox().offset(0.0, 1.3, 0.0));
    }

    /** Ванильная высота прыжка без спринт-буста — движение не дёргается. */
    static void jump(ClientPlayerEntity p) {
        var v = p.getVelocity();
        p.setVelocity(v.x, 0.42, v.z);
    }
}
