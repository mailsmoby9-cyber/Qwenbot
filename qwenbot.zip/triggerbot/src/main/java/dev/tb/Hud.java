package dev.tb;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Индикатор. Строка и цвет пересобираются ТОЛЬКО при переключении. */
final class Hud {

    private static final int COLOR_ON  = 0xFF55FF55;
    private static final int COLOR_OFF = 0xFF9E9E9E;

    private static String label = "TriggerBot: OFF";
    private static int color = COLOR_OFF;

    private Hud() {}

    static void state(boolean on) {
        label = on ? "TriggerBot: ON" : "TriggerBot: OFF";
        color = on ? COLOR_ON : COLOR_OFF;
    }

    static void render(DrawContext ctx) {
        if (!Config.get().hud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        ctx.drawTextWithShadow(mc.textRenderer, label, 4, 4, color);
    }
}
