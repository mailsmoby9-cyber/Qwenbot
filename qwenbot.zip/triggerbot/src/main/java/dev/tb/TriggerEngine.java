package dev.tb;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

/**
 * Два пути: тиковый (полный, крит-удары только здесь) и кадровый (быстрый, суб-тик).
 * Ноль аллокаций в горячем пути, кроме пакетов атаки и одного Box на прыжок.
 */
public final class TriggerEngine {

    private static final double RAD = Math.PI / 180.0;
    private static final double AIM_SLACK = 0.12;
    private static final double MAX_RAY = 6.0;
    private static final int MIN_GAP = 2;
    private static final float RECHARGE_MARK = 0.9f;

    private static boolean enabled, keyWasDown;
    private static int tick;
    private static ClientWorld world;

    private static int lockedId = -1, lockedAt;
    private static int attackTick = -1000;
    private static int period = 12;             // замеряется в бою
    private static boolean periodMeasured = true;
    private static boolean recharged = true;
    private static int critWaitFrom = -1;
    private static boolean serverFalling;       // падение, подтверждённое movement-пакетом

    private TriggerEngine() {}

    static boolean isEnabled() { return enabled; }

    static void toggle() { setEnabled(!enabled); }

    static void setEnabled(boolean on) {
        if (enabled == on) return;
        enabled = on;
        clearTarget();
        MinecraftClient mc = MinecraftClient.getInstance();
        SprintReset.finish(mc);
        Hud.state(on);
        if (mc.player != null) {
            mc.player.sendMessage(
                    Text.literal(on ? "TriggerBot: ON" : "TriggerBot: OFF")
                        .formatted(on ? Formatting.GREEN : Formatting.RED), true);
        }
    }

    static void onDisconnect() {
        setEnabled(false);
        hardReset();
    }

    private static void hardReset() {
        clearTarget();
        SprintReset.reset();
        recharged = true;
        periodMeasured = true;
        period = 12;
        serverFalling = false;
        attackTick = tick - 1000;
    }

    private static void clearTarget() {
        lockedId = -1;
        critWaitFrom = -1;
    }

    /** Кадровый путь: реакция быстрее тика. Вызывается из HUD-колбэка. */
    static void frame(MinecraftClient mc) {
        pollKey(mc);
        if (!enabled || !Config.get().fast) return;
        evaluate(mc, false);
    }

    /** Тиковый путь: идёт сразу после movement-пакета. Только здесь бьём критом. */
    static void tick(MinecraftClient mc) {
        tick++;
        pollKey(mc);

        ClientWorld w = mc.world;
        if (w != world) { world = w; hardReset(); }

        SprintReset.tick(mc, enabled, tick);
        if (!enabled) return;
        evaluate(mc, true);
    }

    private static void evaluate(MinecraftClient mc, boolean tickMode) {
        if (mc.world == null || mc.player == null || mc.interactionManager == null
                || mc.getNetworkHandler() == null) { clearTarget(); return; }
        if (mc.currentScreen != null || mc.isPaused()) { clearTarget(); return; }

        ClientPlayerEntity p = mc.player;
        if (mc.getCameraEntity() != p || !p.isAlive() || p.isSpectator()) { clearTarget(); return; }

        Entity e = Mc.crosshairEntity(mc);
        if (e == null || !valid(mc, p, e)) { clearTarget(); return; }

        Config c = Config.get();
        int id = e.getId();
        if (id != lockedId) { lockedId = id; lockedAt = tick; critWaitFrom = -1; }
        if (tick - lockedAt < c.lockTicks) return;

        float charge = Mc.charge(p);
        if (charge < RECHARGE_MARK) recharged = true;

        if (tickMode) {
            serverFalling = Mc.falling(p);

            if (!periodMeasured && charge >= 1.0f) {
                int measured = tick - attackTick;
                if (measured >= 4 && measured <= 40) period = measured;
                periodMeasured = true;
            }

            // Упреждающий прыжок: фаза падения (t+7) должна совпасть с готовностью удара.
            if (c.critMode == 2 && charge < c.charge) {
                int rem = (int) Math.ceil((1.0f - charge) * period);
                if (rem >= 1 && rem <= c.critLead && canJump(mc, p)) {
                    Mc.jump(p);
                    critWaitFrom = tick;
                }
            }
        }

        if (charge < c.charge) return;
        int gap = tick - attackTick;
        if (gap < MIN_GAP) return;
        if (!recharged && gap < period) return;
        if (p.isUsingItem()) return;
        // В кадровом пути рейкаст свежий этого кадра — проверка не нужна.
        if (tickMode && c.strictAim && !aimOnTarget(p, e.getBoundingBox())) return;

        boolean critReady = c.critMode > 0 && serverFalling
                && Mc.falling(p) && Mc.critEnvironment(p);

        if (c.critMode > 0 && !critReady) {
            boolean possible = Mc.critSoon(p);
            if (!possible && c.critMode == 2 && tickMode && canJump(mc, p)) {
                Mc.jump(p);
                possible = true;
            }
            if (possible) {
                if (critWaitFrom < 0) critWaitFrom = tick;
                if (tick - critWaitFrom < c.critWait) return;
            }
        }

        if (critReady) SprintReset.dropForCrit(mc, p, tick);   // STOP уходит ПЕРЕД атакой
        Mc.attack(mc, p, e);
        if (!critReady) SprintReset.afterAttack(mc, p, tick);

        attackTick = tick;
        periodMeasured = false;
        recharged = false;
        critWaitFrom = -1;
    }

    private static boolean canJump(MinecraftClient mc, ClientPlayerEntity p) {
        return p.isOnGround()
                && !p.isTouchingWater() && !p.isInLava()
                && !p.hasVehicle() && !p.isClimbing() && !p.isFallFlying()
                && !p.isSneaking() && !p.isUsingItem()
                && !mc.options.jumpKey.isPressed()
                && Mc.spaceAbove(mc, p);
    }

    private static void pollKey(MinecraftClient mc) {
        if (mc.currentScreen != null) { keyWasDown = true; return; }
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), Config.get().toggleKey) == GLFW.GLFW_PRESS;
        if (down && !keyWasDown) toggle();
        keyWasDown = down;
    }

    private static boolean valid(MinecraftClient mc, ClientPlayerEntity p, Entity e) {
        if (e == p || !(e instanceof LivingEntity le)) return false;
        if (e.isRemoved() || !e.isAlive() || le.getHealth() <= 0.0f) return false;
        if (e instanceof ArmorStandEntity) return false;

        Config c = Config.get();
        if (e instanceof PlayerEntity pe) {
            if (Mc.protectedMode(mc, pe, c.ignoreCreative)) return false;
            if (c.ignoreTeammates && Mc.sameTeam(p, pe)) return false;
        } else if (c.targetMode == 0 || (c.targetMode == 1 && !(e instanceof HostileEntity))) {
            return false;
        }

        if (c.ignoreInvisible && e.isInvisible()) return false;
        if (c.rangeSq > 0.0 && boxDistSq(p, e) > c.rangeSq) return false;
        return true;
    }

    private static double boxDistSq(Entity from, Entity to) {
        double x = from.getX(), y = from.getEyeY(), z = from.getZ();
        Box b = to.getBoundingBox();
        double dx = Math.max(0.0, Math.max(b.minX - x, x - b.maxX));
        double dy = Math.max(0.0, Math.max(b.minY - y, y - b.maxY));
        double dz = Math.max(0.0, Math.max(b.minZ - z, z - b.maxZ));
        return dx * dx + dy * dy + dz * dz;
    }

    /** Slab-тест луч/бокс по ТЕКУЩЕМУ yaw/pitch. Только примитивы, ноль объектов. */
    private static boolean aimOnTarget(ClientPlayerEntity p, Box b) {
        double yaw = p.getYaw() * RAD, pitch = p.getPitch() * RAD;
        double cp = Math.cos(pitch);
        double dx = -Math.sin(yaw) * cp, dy = -Math.sin(pitch), dz = Math.cos(yaw) * cp;
        double ox = p.getX(), oy = p.getEyeY(), oz = p.getZ();
        double tMin = 0.0, tMax = MAX_RAY;

        double min = b.minX - AIM_SLACK, max = b.maxX + AIM_SLACK;
        if (Math.abs(dx) < 1.0E-7) { if (ox < min || ox > max) return false; }
        else {
            double t1 = (min - ox) / dx, t2 = (max - ox) / dx;
            if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
            if (t1 > tMin) tMin = t1;
            if (t2 < tMax) tMax = t2;
            if (tMin > tMax) return false;
        }

        min = b.minY - AIM_SLACK; max = b.maxY + AIM_SLACK;
        if (Math.abs(dy) < 1.0E-7) { if (oy < min || oy > max) return false; }
        else {
            double t1 = (min - oy) / dy, t2 = (max - oy) / dy;
            if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
            if (t1 > tMin) tMin = t1;
            if (t2 < tMax) tMax = t2;
            if (tMin > tMax) return false;
        }

        min = b.minZ - AIM_SLACK; max = b.maxZ + AIM_SLACK;
        if (Math.abs(dz) < 1.0E-7) { if (oz < min || oz > max) return false; }
        else {
            double t1 = (min - oz) / dz, t2 = (max - oz) / dz;
            if (t1 > t2) { double t = t1; t1 = t2; t2 = t; }
            if (t1 > tMin) tMin = t1;
            if (t2 < tMax) tMax = t2;
            if (tMin > tMax) return false;
        }
        return true;
    }
}
